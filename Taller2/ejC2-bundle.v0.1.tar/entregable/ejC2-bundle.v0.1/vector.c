#include "vector.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


vector_t* nuevo_vector(void) {
}

uint64_t get_size(vector_t* vector) {
}

void push_back(vector_t* vector, uint32_t elemento) {
}

int son_iguales(vector_t* v1, vector_t* v2) {
}

uint32_t iesimo(vector_t* vector, size_t index) {
}

void copiar_iesimo(vector_t* vector, size_t index, uint32_t* out)
{
}


// Dado un array de vectores, devuelve un puntero a aquel con mayor longitud.
vector_t* vector_mas_grande(vector_t** array_de_vectores, size_t longitud_del_array) {
}
